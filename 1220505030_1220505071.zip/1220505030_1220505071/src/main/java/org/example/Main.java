package org.example;
import javax.swing.*;

//Alper Aziz PAKSOY 1220505030
//Mehmet Yigit ERDEM 1220505071

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ButtonControlPanel().show();
            }
        });
    }
}