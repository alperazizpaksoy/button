package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonControlPanel {
    private JButton[][] buttons;
    private int activeButtonRow = -1;
    private int activeButtonCol = -1;
    private JFrame frame;

    public ButtonControlPanel() {
        frame = new JFrame("Button Control Panel");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        buttons = new JButton[4][4];

        // Layout için GridLayout kullanılabilir
        frame.setLayout(new GridLayout(4, 4));

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                buttons[i][j] = createButton(i, j);
                frame.add(buttons[i][j]);
            }
        }
    }

    private JButton createButton(int row, int col) {
        JButton button = new JButton();
        button.setPreferredSize(new Dimension(80, 80));

        // Butonun aktif ve pasif renk özellikleri
        Color activeColor = Color.ORANGE;
        Color inactiveColor = Color.GRAY;
        button.setBackground(inactiveColor);

        // Butonun aktif ve pasif simge özellikleri
        String activeIcon = "O";
        String inactiveIcon = "I";
        button.setText(inactiveIcon);

        // Butona tiklandigini anlamasi icin (uygulamanin)
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (row != activeButtonRow || col != activeButtonCol) {
                    // Eğer farklı bir butona basıldıysa
                    deactivateButtons();
                    activeButtonRow = row;
                    activeButtonCol = col;
                    button.setBackground(activeColor);
                    button.setText(activeIcon);

                    // TODO: Belirlediğiniz GraphQL şemasında mutation çalıştırma işlemi

                } else {
                    // Eğer aynı butona tekrar basıldıysa
                    deactivateButtons();
                }
            }
        });

        return button;
    }

    private void deactivateButtons() {
        // Tüm butonları pasif hale getir
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                buttons[i][j].setBackground(Color.GRAY);
                buttons[i][j].setText("I");
            }
        }
        activeButtonRow = -1;
        activeButtonCol = -1;
    }

    public void show() {
        frame.setVisible(true);
    }
}
